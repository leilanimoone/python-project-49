# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/leilanimoone/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/leilanimoone/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/8579fdead27eaada1b06/maintainability)](https://codeclimate.com/github/leilanimoone/python-project-49/maintainability)\n### Brain Games consists of 5 math-related games.\n### The results of the work are given below:\n### Installing package and game-even:\n[![asciicast](https://asciinema.org/a/SSbOtEtKomvvIu3XLBZluk8rm.svg)](https://asciinema.org/a/SSbOtEtKomvvIu3XLBZluk8rm)\n### Game-calc:\n[![asciicast](https://asciinema.org/a/pqx8g9agVME5KdIi6r0GU1AMJ.svg)](https://asciinema.org/a/pqx8g9agVME5KdIi6r0GU1AMJ)\n### Game-gcd:\n[![asciicast](https://asciinema.org/a/uTHGQT7OP5I7Wd21kmy4JIiTM.svg)](https://asciinema.org/a/uTHGQT7OP5I7Wd21kmy4JIiTM)\n### Game-progression:\n[![asciicast](https://asciinema.org/a/4JLeM9qihbX4iAzFFxd0EmAZK.svg)](https://asciinema.org/a/4JLeM9qihbX4iAzFFxd0EmAZK)\n### Game-prime:\n[![asciicast](https://asciinema.org/a/qYS4cAEXpAPf5KZtPpVQpswLV.svg)](https://asciinema.org/a/qYS4cAEXpAPf5KZtPpVQpswLV)\n',
    'author': 'Lera',
    'author_email': 'leilanimoone@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/leilanimoone/python-project-49.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
