### Hexlet tests and linter status:
[![Actions Status](https://github.com/leilanimoone/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/leilanimoone/python-project-49/actions)
<a href="https://codeclimate.com/github/leilanimoone/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8579fdead27eaada1b06/maintainability" /></a>
 https://asciinema.org/connect/2666bde2-bf45-4438-9670-272ca22b5bcf
