### Hexlet tests and linter status:
[![Actions Status](https://github.com/leilanimoone/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/leilanimoone/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/8579fdead27eaada1b06/maintainability)](https://codeclimate.com/github/leilanimoone/python-project-49/maintainability)
### Brain Games consists of 5 math-related games.
### The results of the work are given below:
### Installing package and game-even:
[![asciicast](https://asciinema.org/a/SSbOtEtKomvvIu3XLBZluk8rm.svg)](https://asciinema.org/a/SSbOtEtKomvvIu3XLBZluk8rm)
### Game-calc:
[![asciicast](https://asciinema.org/a/pqx8g9agVME5KdIi6r0GU1AMJ.svg)](https://asciinema.org/a/pqx8g9agVME5KdIi6r0GU1AMJ)
### Game-gcd:
[![asciicast](https://asciinema.org/a/uTHGQT7OP5I7Wd21kmy4JIiTM.svg)](https://asciinema.org/a/uTHGQT7OP5I7Wd21kmy4JIiTM)
### Game-progression:
[![asciicast](https://asciinema.org/a/4JLeM9qihbX4iAzFFxd0EmAZK.svg)](https://asciinema.org/a/4JLeM9qihbX4iAzFFxd0EmAZK)
### Game-prime:
[![asciicast](https://asciinema.org/a/qYS4cAEXpAPf5KZtPpVQpswLV.svg)](https://asciinema.org/a/qYS4cAEXpAPf5KZtPpVQpswLV)
