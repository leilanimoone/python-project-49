### Hexlet tests and linter status:
[![Actions Status](https://github.com/leilanimoone/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/leilanimoone/python-project-49/actions)
<a href="https://codeclimate.com/github/leilanimoone/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8579fdead27eaada1b06/maintainability" /></a>
https://asciinema.org/connect/2666bde2-bf45-4438-9670-272ca22b5bcf
https://asciinema.org/a/pqx8g9agVME5KdIi6r0GU1AMJ
https://asciinema.org/a/uTHGQT7OP5I7Wd21kmy4JIiTM
https://asciinema.org/a/4JLeM9qihbX4iAzFFxd0EmAZK
https://asciinema.org/a/qYS4cAEXpAPf5KZtPpVQpswLV
