#!/usr/bin/env python3
from brain_games.games import prime
from brain_games.foundation import brain_games


def main():
    brain_games(prime)


if __name__ == '__main__':
    main()
