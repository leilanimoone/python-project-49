#!/usr/bin/env python3
from brain_games.games import even
from brain_games.foundation import brain_games


def main():
    brain_games(even)


if __name__ == '__main__':
    main()
